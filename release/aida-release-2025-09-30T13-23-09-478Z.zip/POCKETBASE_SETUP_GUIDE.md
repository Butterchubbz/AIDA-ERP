# PocketBase Setup for AIDA (quick)

This guide shows the manual steps to prepare PocketBase for local AIDA development.

Prerequisites:

- Downloaded `pocketbase` and able to run it locally.
- Admin username/password (created when you first open the Admin UI).

1. Download and run PocketBase (PowerShell example)

```powershell
cd C:\path\to\pocketbase
.\pocketbase.exe serve
```

Open the Admin UI at `http://127.0.0.1:8090/_/` and create an admin account when prompted.

2. Create the collections AIDA needs (Manual)

- In the Admin UI go to **Collections** and create each collection required (e.g., `refurbishedDevices`, `devices`, `inventory`, `users`).
- Add fields and API rules manually as required by your workflow (for local development you can set List/View/Create/Update/Delete to **Auth** or as needed).

3. Add a user to the `users` collection

- Create a regular user to log into the AIDA frontend.

4. Start the frontend

```powershell
cd AIDA
npm install
npm run dev
```

Open the frontend (usually `http://localhost:5173/`) and log in with the user you created.

If you later decide you want automation, consider a server-side/CI script that uses admin credentials to create collections and seed data; that approach is safer than shipping admin automation in the client or repository.

Importing seed data (optional)

- In the Admin UI go to **Settings → Data** and use the import tool to import the provided `pocketbase/seed.json` file. This will create empty collections with the fields defined in the seed file.

Run PocketBase with Docker Compose (optional)

Create a `docker-compose.yml` file and run:

```yaml
version: '3.8'
services:
	pocketbase:
		image: ghcr.io/pocketbase/pocketbase:latest
		ports:
			- "8090:8090"
		volumes:
			- ./pb_data:/pb_data
		command: serve --http=0.0.0.0:8090

# After starting, open http://localhost:8090/_/ to access the admin UI
```

Notes

- The `pocketbase/seed.json` is a minimal example showing collection names and fields; you will probably want to enhance the schema to match your app's needs (indexes, rules, relations).
- Do not store admin credentials or DSNs in the repository. Use environment variables for sensitive values.
